﻿using System;
using System.IO;

namespace BoxArchive
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] prepared = Logic.PrepareData(new FileInfo("xp20.png"), new FileInfo("xpbox.png"), new FileInfo("konki.pptx"), new FileInfo("null_copy.png"));

            File.WriteAllBytes("test.INT", prepared);

            Logic.CompressFile("test.INT", "test.BOX");

            File.Delete("test.INT");

            Logic.DecompressFile("test.BOX", "test.INT");

            Logic.UnpackFiles(File.ReadAllBytes("test.INT"), Directory.CreateDirectory("testdir"));
        }
    }
}


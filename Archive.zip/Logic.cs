﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO.Compression;

namespace BoxArchive
{
    public class Logic
    {

        private const string START = "STaRT";

        private const string SEPARATOR = "SEParaTOR";

        private static void ErrorRoutine(string message)
        {
            Console.WriteLine($"Ошибка. Пожалуйста, свяжитесь с Вашим системным администратором.\nСообщение для отладки: {message}\n");
            Console.WriteLine("Исполнение завершено.");

            Console.ReadKey(true);

            Environment.Exit(0);
        }

        public static byte[] PrepareData(params FileInfo[] files)
        {
            try
            {
                Console.WriteLine("Процесс подготовки файлов запущен.");

                List<byte> header = new List<byte>();
                List<byte> preparedData = new List<byte>();

                byte[] rule = Encoding.Latin1.GetBytes(SEPARATOR);

                byte[] start = Encoding.Latin1.GetBytes(START);

                for (int i = 0; i < files.Length; i++)
                {
                    header.AddRange(Encoding.Latin1.GetBytes($"{i} " + files[i].Name + "\t").Cast<byte>());
                }

                header.AddRange(start);

                preparedData.AddRange(header);

                foreach (FileInfo i in files)
                {
                    preparedData.AddRange(File.ReadAllBytes(i.FullName).Concat(rule));
                }

                preparedData.Reverse();

                Console.WriteLine("Процесс подготовки файлов завершен.");

                return preparedData.ToArray();
            }
            catch (Exception e)
            {
                ErrorRoutine(e.Message);
                return null;
            }
        }

        public static void CompressFile(string filename, string destfile)
        {
            using FileStream originalFileStream = File.Open(filename, FileMode.Open);
            using FileStream compressedFileStream = File.Create(destfile);
            using var compressor = new GZipStream(compressedFileStream, CompressionLevel.Optimal);
            originalFileStream.CopyTo(compressor);
        }

        public static void DecompressFile(string filename, string destfile)
        {
            using FileStream compressedFileStream = File.Open(filename, FileMode.Open);
            using FileStream outputFileStream = File.Create(destfile);
            using var decompressor = new GZipStream(compressedFileStream, CompressionMode.Decompress);
            decompressor.CopyTo(outputFileStream);
        }

        public static void UnpackFiles(byte[] data, DirectoryInfo dir)
        {
            try
            {
                Array.Reverse(data);

                string prevDir = Directory.GetCurrentDirectory();

                Console.WriteLine("Процесс распаковки файлов запущен.");

                Regex headerSplitter = new Regex(START);
                Regex fileSplitter = new Regex(SEPARATOR);

                string toParse = Encoding.Latin1.GetString(data);

                string[] parsed1 = headerSplitter.Split(toParse);

                string[] parsed2 = fileSplitter.Split(parsed1[1]);

                string[] parsedHeader = parsed1[0].Split('\t').Where(f => f != string.Empty).ToArray();

                Dictionary<int, string> namesAndIndexes = new Dictionary<int, string>();

                for (int i = 0; i < parsedHeader.Length; i++)
                {
                    string[] current = parsedHeader[i].Split(' ');

                    namesAndIndexes.Add(int.Parse(current[0]), current[1]);
                }

                byte[][] parsedData = new byte[][] { };

                Directory.SetCurrentDirectory(prevDir);
                Console.WriteLine("Процесс распаковки файлов завершен.");


                for (int i = 0; i < parsed2.Length; i++)
                {
                    Array.Resize(ref parsedData, parsedData.Length + 1);
                    parsedData[i] = Encoding.Latin1.GetBytes(parsed2[i]);
                }

                parsedData = parsedData.Where(f => f.Length > 0).ToArray();

                for (int i = 0; i < parsedData.Length; i++)
                {
                    if (parsedData.Length == namesAndIndexes.Keys.ToArray().Length)
                    {
                        if (!File.Exists(Path.Combine(dir.Name, namesAndIndexes[i])))
                        {
                            File.Create(Path.Combine(dir.Name, namesAndIndexes[i])).Dispose();
                        }
                        File.WriteAllBytes(Path.Combine(dir.Name, namesAndIndexes[i]), parsedData[i]);
                    }

                }

                Directory.SetCurrentDirectory(prevDir);
                Console.WriteLine("Процесс распаковки файлов завершен.");
            }
            catch (Exception e)
            {
                ErrorRoutine(e.Message);
            }
        }
    }
}
